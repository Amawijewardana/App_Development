# ApplicationController is the base controller class for the application.
# It provides common methods and filters that can be used across multiple controllers.

class ApplicationController < ActionController::Base
    # Make the following methods accessible from views as helper methods.
    helper_method :current_user, :logged_in?, :is_administrator?

    # Retrieves the currently logged-in user based on the session[:user_id].
    # Caches the result to avoid unnecessary database queries.
    def current_user
        @current_user ||= User.find_by(id: session[:user_id])
    end

    # Checks if a user is currently logged in.
    # Returns true if there is a current user, false otherwise.
    def logged_in?
        !current_user.nil?
    end

    # Checks if the current user is an administrator based on the session[:is_admin] flag.
    # Returns true if the user is an administrator, false otherwise.
    def is_administrator?
        session[:is_admin]
    end      

    private

    # A filter method to restrict access to certain actions or resources.
    # Redirects users to the login page if they are not logged in.
    def require_login
        unless logged_in?
            flash[:error] = "You are not permitted to access this resource"
            redirect_to login_path
        end
    end
end
