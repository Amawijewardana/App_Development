# CategoriesController handles the CRUD operations for categories.
# It allows creating, reading, updating, and deleting category records.

class CategoriesController < ApplicationController
  before_action :set_category, only: %i[ show edit update destroy ]

  # GET /categories or /categories.json
  # Fetches all categories from the database and assigns them to @categories for display.
  def index
    @categories = Category.all
  end

  # GET /categories/1 or /categories/1.json
  # Retrieves a specific category based on the provided ID and assigns it to @category for display.
  def show
  end

  # GET /categories/new
  # Initializes a new Category object for creating a new category record.
  def new
    @category = Category.new
  end

  # GET /categories/1/edit
  # Retrieves a specific category based on the provided ID for editing.
  def edit
  end

  # POST /categories or /categories.json
  # Handles the creation of a new category based on the provided parameters.
  def create
    @category = Category.new(category_params)

    respond_to do |format|
      if @category.save
        format.html { redirect_to category_url(@category), notice: "Category was successfully created." }
        format.json { render :show, status: :created, location: @category }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @category.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /categories/1 or /categories/1.json
  # Handles the update of an existing category based on the provided parameters.
  def update
    respond_to do |format|
      if @category.update(category_params)
        format.html { redirect_to category_url(@category), notice: "Category was successfully updated." }
        format.json { render :show, status: :ok, location: @category }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @category.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /categories/1 or /categories/1.json
  # Handles the deletion of a category based on the provided ID.
  def destroy
    @category.destroy

    respond_to do |format|
      format.html { redirect_to categories_url, notice: "Category was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    # Retrieves a specific category based on the provided ID and assigns it to @category.
    def set_category
      @category = Category.find(params[:id])
    end

    # Defines the parameters that are allowed to be submitted for category creation and update.
    def category_params
      params.require(:category).permit(:categoryname)
    end
end

