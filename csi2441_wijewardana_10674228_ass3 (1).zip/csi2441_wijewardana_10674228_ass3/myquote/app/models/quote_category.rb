class QuoteCategory < ApplicationRecord
  belongs_to :quote, class_name: 'Quote', foreign_key: 'quote_id'
  belongs_to :category, class_name: 'Category', foreign_key: 'category_id'
end





