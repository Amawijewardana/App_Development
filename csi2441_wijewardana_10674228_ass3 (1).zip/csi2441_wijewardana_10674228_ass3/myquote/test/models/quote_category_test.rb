require "test_helper"

class QuoteCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
