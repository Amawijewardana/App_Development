require "test_helper"

class PhilosophersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @philosopher = philosophers(:one)
  end

  test "should get index" do
    get philosophers_url
    assert_response :success
  end

  test "should get new" do
    get new_philosopher_url
    assert_response :success
  end

  test "should create philosopher" do
    assert_difference("Philosopher.count") do
      post philosophers_url, params: { philosopher: { philosopher_bio: @philosopher.philosopher_bio, philosopher_birthyear: @philosopher.philosopher_birthyear, philosopher_deathyear: @philosopher.philosopher_deathyear, philosopher_firstname: @philosopher.philosopher_firstname, philosopher_surname: @philosopher.philosopher_surname } }
    end

    assert_redirected_to philosopher_url(Philosopher.last)
  end

  test "should show philosopher" do
    get philosopher_url(@philosopher)
    assert_response :success
  end

  test "should get edit" do
    get edit_philosopher_url(@philosopher)
    assert_response :success
  end

  test "should update philosopher" do
    patch philosopher_url(@philosopher), params: { philosopher: { philosopher_bio: @philosopher.philosopher_bio, philosopher_birthyear: @philosopher.philosopher_birthyear, philosopher_deathyear: @philosopher.philosopher_deathyear, philosopher_firstname: @philosopher.philosopher_firstname, philosopher_surname: @philosopher.philosopher_surname } }
    assert_redirected_to philosopher_url(@philosopher)
  end

  test "should destroy philosopher" do
    assert_difference("Philosopher.count", -1) do
      delete philosopher_url(@philosopher)
    end

    assert_redirected_to philosophers_url
  end
end
